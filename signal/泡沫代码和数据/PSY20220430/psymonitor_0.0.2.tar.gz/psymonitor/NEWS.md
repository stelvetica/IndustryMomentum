# psymonitor 0.0.2

Fixed RNG compatibility issues.

# psymonitor 0.0.1.9000

* Added rendered vignettes.

# psymonitor 0.0.1

* First stable release to CRAN.

# psymonitor 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
